from django.contrib import admin
from server.models import Person,Polymer
# Register your models here.

class PersonAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'age', 'time']

class PolymerAdmin(admin.ModelAdmin):
    list_display = ['id', 'polymer_mn', 'polymer_pdi', 'monomer_mw']

admin.site.register(Person, PersonAdmin)
admin.site.register(Polymer, PolymerAdmin)