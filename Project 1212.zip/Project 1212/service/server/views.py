import codecs
import struct
from django.shortcuts import render
from django.http import HttpResponse
from server import models
import json
import uuid
from django.core import serializers
from django.core.serializers.json import DjangoJSONEncoder
from server.models import Person,Polymer
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd #data reading
import peakutils as peakutils #peakutils.baseline
import math
import csv
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.dates import DateFormatter
import random
import datetime
from io import BytesIO
from PIL import Image
import base64
# Create your views here.
buffer = BytesIO()

def LN(x, x0, sigma):
    return 1 / sigma / np.sqrt(2 * np.pi) / x * np.exp(-1 / 2 / (sigma ** 2) * (np.log(x / x0)) ** 2)

def write_polymer_server(request):
    data = json.loads(request.body)
    final_json = json.dumps(data, ensure_ascii=False)
    with codecs.open("polymer.json", 'w', 'utf-8') as file:
        file.write(final_json)
    data['id'] = uuid.uuid4()
    # print(data)
    value_a = float(data['polymer_mn'])
    value_b = float(data['polymer_pdi'])
    value_c = float(data['monomer_mw'])
    print(value_a, value_b, value_c)
    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))
    Mw = np.arange(1e2, 5e5, Mw_mono)
    LN2 = np.vectorize(LN)
    result = LN2(Mw, M0, sigma2)
    fig, ax = plt.subplots()
    ax.semilogx(Mw, result,'.',color='darkgreen')
    plt.title('Polymer GPC')
    # plt.savefig(buffer)
    # plt.show()
    plt.savefig('img.jpeg')
    plt.close('all')
    # models.Polymer.objects.create(**data)

    res = {
        'success':True
    }
    return HttpResponse(json.dumps(res), content_type='application/json')


def read_server(request):
    name = request.GET['name']
    data = serializers.serialize('python', models.Person.objects.filter(name = name))
    res = {
        'success':True,
        'data':data
    }
    return HttpResponse(json.dumps(res, cls=DjangoJSONEncoder), content_type='application/json')

def img(request):
    accept_format = request.META.get('HTTP_ACCEPT', 'image/jpeg')
    im = Image.open('img.jpeg')
    # im.show()
    file = BytesIO()
    im.save(file, 'jpeg')
    data = file.getvalue()
    # data = base64.b64encode(data)
    return HttpResponse(data,content_type='image/jpeg')

def img2(request):
    accept_format = request.META.get('HTTP_ACCEPT', 'image/jpeg')
    im = Image.open('img2.jpeg')
    # im.show()
    file = BytesIO()
    im.save(file, 'jpeg')
    data = file.getvalue()
    # data = base64.b64encode(data)
    return HttpResponse(data,content_type='image/jpeg')

def img3(request):
    accept_format = request.META.get('HTTP_ACCEPT', 'image/jpeg')
    im = Image.open('img3.jpeg')
    # im.show()
    file = BytesIO()
    im.save(file, 'jpeg')
    data = file.getvalue()
    # data = base64.b64encode(data)
    return HttpResponse(data,content_type='image/jpeg')

def img4(request):
    accept_format = request.META.get('HTTP_ACCEPT', 'image/jpeg')
    im = Image.open('img4.jpeg')
    # im.show()
    file = BytesIO()
    im.save(file, 'jpeg')
    data = file.getvalue()
    # data = base64.b64encode(data)
    return HttpResponse(data,content_type='image/jpeg')

def handle_csv(request):
    data = request.body;
    data = bytes.decode(data)
    # print("接收到的文件",type(data),data)
    fh = open('666.txt', 'w', encoding='utf-8')
    fh.write(data)

    fh.close()

    f = open('666.txt')
    lines = f.readlines()
    f.close()
    strout = ''.join(lines[9:-3])
    # print(lines[5:-3])
    fh = open('666.txt', 'w', encoding='utf-8')
    fh.write(strout)
    fh.close()
    with open("protein.json") as json_file:
        protein = json.load(json_file)
    # print(protein)
    Mw_initiator, Mw_protein, degree_of_initiator = float(protein['initiator_mw']), float(protein['protein_mw']),int(protein['degree_of_initiator']),
    with open('666.txt', encoding="utf-8") as f:
        # pass
        data = np.loadtxt(f, delimiter=",", skiprows=1)
        x2 = data[:, 0]
        y2 = data[:, 1]
    f.close()
    base = peakutils.baseline(np.asarray(y2), deg=1, max_it=100000, tol=.0001)  # deg, max_it, tol can be customized
    y2_baselined = y2 - base
    y2 = y2_baselined / np.sum(y2_baselined)
    plt.plot(x2, y2,'.', color='darkgreen')
    plt.xlim(0.95 * Mw_protein, (Mw_protein + Mw_initiator*degree_of_initiator)*1.05)
    plt.title('Protein MALDI')
    plt.axvline(Mw_protein, color='g')
    for i in range(degree_of_initiator):
        plt.axvline(Mw_protein + Mw_initiator * (i + 1), color='coral', ls='--')

    # plt.show()
    plt.savefig('img2.jpeg')
    plt.close('all')
    a, d = Mw_protein, Mw_initiator
    x = x2
    # y = LN(z1,(25806.9*25837.0)**0.5,np.sqrt(np.log(25837.0/25806.9)))
    y = y2
    x = np.array(x)
    y = np.array(y)

    sample_step_x_p = []
    sample_step_y_p = []

    step = d
    for i in range(int(a), int(a + degree_of_initiator * d), int(step)):
        begin = i
        end = i + step
        candidate = []
        candidate = np.array(candidate)
        candidate = candidate.astype('int64')
        for j in range(0, x.size):
            if (x[j] <= end) and (x[j] >= begin):
                # print(x[j])
                candidate = np.append(candidate, int(j))
        # print(candidate)
        if (candidate.size == 0):
            continue
        x_sample = x[candidate]
        y_sample = y[candidate]
        x_ave = np.mean(x_sample)
        y_ave = np.mean(y_sample)
        sample_step_x_p = np.append(sample_step_x_p, x_ave)
        sample_step_y_p = np.append(sample_step_y_p, y_ave)
    sample_step_x_p = sample_step_x_p
    sample_step_y_p = sample_step_y_p / np.sum(sample_step_y_p)
    # print(type(sample_step_y_p))
    np.save("massratios.npy", sample_step_y_p)

    test = np.load("massratios.npy")
    print("mass",test)
    protein5 = []
    for i,item in enumerate(test):
        protein5.append({"number_of_initiators": i+1, "percentage": item})
    print(protein5)
    protein5_output = {"protein":protein5}
    final_json = json.dumps(protein5_output, ensure_ascii=False)
    with codecs.open("protein5.json", 'w', 'utf-8') as file:
        file.write(final_json)
    res = {
        'success': True
    }
    return HttpResponse(json.dumps(res), content_type='application/json')

def write_protein(request):
    data = json.loads(request.body)
    # print(type(data))
    value_a = float(data['initiator_mw'])
    value_b = float(data['protein_mw'])
    value_c = float(data['degree_of_initiator'])
    final_json = json.dumps(data, ensure_ascii=False)
    with codecs.open("protein.json", 'w', 'utf-8') as file:
        file.write(final_json)
    res = {
        'success': True
    }
    protein6 = {
        'protein_mw':data["protein_mw"],
        'degree_of_initiator':data["degree_of_initiator"]
    }
    protein6_json = json.dumps(protein6, ensure_ascii=False)
    with codecs.open("protein6.json", 'w', 'utf-8') as file:
        file.write(protein6_json)
    print(data["degree_of_initiator"],data["protein_mw"])
    res = {
        'success': True
    }
    return HttpResponse(json.dumps(res), content_type='application/json')

def conjugate1(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])


    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator

    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N__1 = []
    P__1= []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1 = []
        P1 = []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    n2 = N__1
    p2 = P__1
    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')

def conjugate2(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2 = [], []
    P__1, P__2 = [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2 = [], []
        P1, P2 = [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)


        N_2_proxy = np.concatenate((N1, N2), axis=0)
        P_2_proxy = np.concatenate((P1, P2), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')

def conjugate3(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3 = [], [], []
    P__1, P__2, P__3 = [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3 = [], [], []
        P1, P2, P3 = [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)

        N_2_proxy = np.concatenate((N1, N2, N3), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')

def conjugate4(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4 = [], [], [], []
    P__1, P__2, P__3, P__4 = [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4 = [], [], [], []
        P1, P2, P3, P4 = [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)

        N_2_proxy = np.concatenate((N1, N2, N3, N4), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')

def conjugate5(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)
    # print(len(x1_2))
    # print(M0,sigma2)
    print(Mn_tot,Mw_tot)
    # print(y1_2[0][0],x1_2[0][0],Mw_new[0],LN(1000,M0,sigma2))

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5 = [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5 = [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5 = [], [], [], [], []
        P1, P2, P3, P4, P5 = [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2
    # print(np.min(n2),np.max(n2))
    # print(len(n2))
    print(np.min(p2), np.max(p2))

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')

def conjugate6(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6 = [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6 = [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6 = [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6 = [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')

def conjugate7(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7 = [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7 = [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7 =  [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7 =  [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 9},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate8(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7, N__8 = [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8 = [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8 =  [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8 =  [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 9},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate9(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7, N__8, N__9 = [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9 = [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9 = [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9 = [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 8},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate10(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7, N__8, N__9, N__10 =  [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10 =  [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10 =  [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10 =  [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 8},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate11(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator

    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7, N__8, N__9, N__10, N__11 =  [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11 =  [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11 =  [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11 =  [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 8},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate12(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7, N__8, N__9, N__10, N__11, N__12 =  [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12 =  [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12 =  [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12 =  [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 8},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')




def conjugate13(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7, N__8, N__9, N__10, N__11, N__12, N__13 =  [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13 =  [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13 =  [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13 =  [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 7},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate14(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))

    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))

    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6, N__7, N__8, N__9, N__10, N__11, N__12, N__13, N__14 =  [], [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13, P__14 =  [], [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14 =  [], [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14 =  [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)
        for i in range(step ** 13):
            for j in range(step):
                N14.append(N13[i] + x1[j])
                P14.append((P13[i] + y1[j]) * sample_step_y_p[13])
        N__14.extend(N14)
        P__14.extend(P14)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    plt.plot(N__14, P__14, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 7},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot = round(Mn_tot, 2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI, 2)
        res = {
            'success': True,
            'Mn': Mn_tot,
            'Mw': Mw_tot,
            'PDI': PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')


def conjugate15(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6 ,N__7, N__8, N__9, N__10, N__11, N__12, N__13, N__14, N__15 =  [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13, P__14, P__15 =  [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15= [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15= [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)
        for i in range(step ** 13):
            for j in range(step):
                N14.append(N13[i] + x1[j])
                P14.append((P13[i] + y1[j]) * sample_step_y_p[13])
        N__14.extend(N14)
        P__14.extend(P14)
        for i in range(step ** 14):
            for j in range(step):
                N15.append(N14[i] + x1[j])
                P15.append((P14[i] + y1[j]) * sample_step_y_p[14])
        N__15.extend(N15)
        P__15.extend(P15)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    plt.plot(N__14, P__14, '.')
    plt.plot(N__15, P__15, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 7},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate16(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6 ,N__7, N__8, N__9, N__10, N__11, N__12, N__13, N__14, N__15, N__16 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13, P__14, P__15, P__16 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16= [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16= [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)
        for i in range(step ** 13):
            for j in range(step):
                N14.append(N13[i] + x1[j])
                P14.append((P13[i] + y1[j]) * sample_step_y_p[13])
        N__14.extend(N14)
        P__14.extend(P14)
        for i in range(step ** 14):
            for j in range(step):
                N15.append(N14[i] + x1[j])
                P15.append((P14[i] + y1[j]) * sample_step_y_p[14])
        N__15.extend(N15)
        P__15.extend(P15)
        for i in range(step ** 15):
            for j in range(step):
                N16.append(N15[i] + x1[j])
                P16.append((P15[i] + y1[j]) * sample_step_y_p[15])
        N__16.extend(N16)
        P__16.extend(P16)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    plt.plot(N__14, P__14, '.')
    plt.plot(N__15, P__15, '.')
    plt.plot(N__16, P__16, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 7},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')


def conjugate17(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6 ,N__7, N__8, N__9, N__10, N__11, N__12, N__13, N__14, N__15, N__16 ,N__17 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13, P__14, P__15, P__16, P__17 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17= [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17= [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)
        for i in range(step ** 13):
            for j in range(step):
                N14.append(N13[i] + x1[j])
                P14.append((P13[i] + y1[j]) * sample_step_y_p[13])
        N__14.extend(N14)
        P__14.extend(P14)
        for i in range(step ** 14):
            for j in range(step):
                N15.append(N14[i] + x1[j])
                P15.append((P14[i] + y1[j]) * sample_step_y_p[14])
        N__15.extend(N15)
        P__15.extend(P15)
        for i in range(step ** 15):
            for j in range(step):
                N16.append(N15[i] + x1[j])
                P16.append((P15[i] + y1[j]) * sample_step_y_p[15])
        N__16.extend(N16)
        P__16.extend(P16)
        for i in range(step ** 16):
            for j in range(step):
                N17.append(N16[i] + x1[j])
                P17.append((P16[i] + y1[j]) * sample_step_y_p[16])
        N__17.extend(N17)
        P__17.extend(P17)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    plt.plot(N__14, P__14, '.')
    plt.plot(N__15, P__15, '.')
    plt.plot(N__16, P__16, '.')
    plt.plot(N__17, P__17, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 6},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate18(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6 ,N__7, N__8, N__9, N__10, N__11, N__12, N__13, N__14, N__15, N__16 ,N__17, N__18 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13, P__14, P__15, P__16, P__17, P__18 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17, N18= [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18= [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)
        for i in range(step ** 13):
            for j in range(step):
                N14.append(N13[i] + x1[j])
                P14.append((P13[i] + y1[j]) * sample_step_y_p[13])
        N__14.extend(N14)
        P__14.extend(P14)
        for i in range(step ** 14):
            for j in range(step):
                N15.append(N14[i] + x1[j])
                P15.append((P14[i] + y1[j]) * sample_step_y_p[14])
        N__15.extend(N15)
        P__15.extend(P15)
        for i in range(step ** 15):
            for j in range(step):
                N16.append(N15[i] + x1[j])
                P16.append((P15[i] + y1[j]) * sample_step_y_p[15])
        N__16.extend(N16)
        P__16.extend(P16)
        for i in range(step ** 16):
            for j in range(step):
                N17.append(N16[i] + x1[j])
                P17.append((P16[i] + y1[j]) * sample_step_y_p[16])
        N__17.extend(N17)
        P__17.extend(P17)
        for i in range(step ** 17):
            for j in range(step):
                N18.append(N17[i] + x1[j])
                P18.append((P17[i] + y1[j]) * sample_step_y_p[17])
        N__18.extend(N18)
        P__18.extend(P18)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17, N18), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    plt.plot(N__14, P__14, '.')
    plt.plot(N__15, P__15, '.')
    plt.plot(N__16, P__16, '.')
    plt.plot(N__17, P__17, '.')
    plt.plot(N__18, P__18, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 6},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')



def conjugate19(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6 ,N__7, N__8, N__9, N__10, N__11, N__12, N__13, N__14, N__15, N__16 ,N__17, N__18, N__19 =  [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13, P__14, P__15, P__16, P__17, P__18, P__19 =  [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17, N18, N19 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)
        for i in range(step ** 13):
            for j in range(step):
                N14.append(N13[i] + x1[j])
                P14.append((P13[i] + y1[j]) * sample_step_y_p[13])
        N__14.extend(N14)
        P__14.extend(P14)
        for i in range(step ** 14):
            for j in range(step):
                N15.append(N14[i] + x1[j])
                P15.append((P14[i] + y1[j]) * sample_step_y_p[14])
        N__15.extend(N15)
        P__15.extend(P15)
        for i in range(step ** 15):
            for j in range(step):
                N16.append(N15[i] + x1[j])
                P16.append((P15[i] + y1[j]) * sample_step_y_p[15])
        N__16.extend(N16)
        P__16.extend(P16)
        for i in range(step ** 16):
            for j in range(step):
                N17.append(N16[i] + x1[j])
                P17.append((P16[i] + y1[j]) * sample_step_y_p[16])
        N__17.extend(N17)
        P__17.extend(P17)
        for i in range(step ** 17):
            for j in range(step):
                N18.append(N17[i] + x1[j])
                P18.append((P17[i] + y1[j]) * sample_step_y_p[17])
        N__18.extend(N18)
        P__18.extend(P18)
        for i in range(step ** 18):
            for j in range(step):
                N19.append(N18[i] + x1[j])
                P19.append((P18[i] + y1[j]) * sample_step_y_p[18])
        N__19.extend(N19)
        P__19.extend(P19)


        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17, N18, N19), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    plt.plot(N__14, P__14, '.')
    plt.plot(N__15, P__15, '.')
    plt.plot(N__16, P__16, '.')
    plt.plot(N__17, P__17, '.')
    plt.plot(N__18, P__18, '.')
    plt.plot(N__19, P__19, '.')

    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 6},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')


def conjugate20(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    # print(polymer)
    value_a = float(polymer['polymer_mn'])
    value_b = float(polymer['polymer_pdi'])
    value_c = float(polymer['monomer_mw'])
    min = float(polymer['min'])
    max = float(polymer['max'])

    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    degree_of_initiator = int(protein6['degree_of_initiator'])
    a = int(protein6['protein_mw'])
    min2 = a + min
    max2 = a + max * degree_of_initiator
    with open("conjugate.json") as json_file:
        conjugate = json.load(json_file)

    Number_polymer = int(conjugate['Number_polymer'])
    step = int(conjugate['step'])
    Smoothfactor = int(conjugate['Smoothfactor'])

    Mw_new = 10**(np.linspace(np.log10(min), np.log10(max), Number_polymer))


    Mn_tot, PDI, Mw_mono = value_a, value_b, value_c
    Mw_tot = Mn_tot * PDI
    M0 = (Mn_tot * Mw_tot) ** 0.5
    sigma2 = np.sqrt(np.log(Mw_tot / Mn_tot))


    x1_2_new = Mw_new
    y1_2_new = LN(Mw_new, M0, sigma2)

    x1_2 = [x1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    y1_2 = [y1_2_new[i:i + step] for i in range(0, len(x1_2_new), step)]
    sample_step_y_p = np.load("massratios.npy")
    print(sample_step_y_p)

    N_2, P_2 = [], []
    N__1, N__2, N__3, N__4, N__5, N__6 ,N__7, N__8, N__9, N__10, N__11, N__12, N__13, N__14, N__15, N__16 ,N__17, N__18, N__19, N__20 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    P__1, P__2, P__3, P__4, P__5, P__6, P__7, P__8, P__9, P__10, P__11, P__12, P__13, P__14, P__15, P__16, P__17, P__18, P__19, P__20 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
    for ii in range(len(x1_2) - 1):
        x1 = x1_2[ii]
        y1 = y1_2[ii]
        N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17, N18, N19, N20 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19, P20 = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for i in range(step):
            N1.append(x1[i] + a)
            P1.append(y1[i] * sample_step_y_p[0])
        N__1.extend(N1)
        P__1.extend(P1)
        for i in range(step):
            for j in range(step):
                N2.append(N1[i] + x1[j])
                P2.append((P1[i] + y1[j]) * sample_step_y_p[1])
        N__2.extend(N2)
        P__2.extend(P2)
        for i in range(step ** 2):
            for j in range(step):
                N3.append(N2[i] + x1[j])
                P3.append((P2[i] + y1[j]) * sample_step_y_p[2])
        N__3.extend(N3)
        P__3.extend(P3)
        for i in range(step ** 3):
            for j in range(step):
                N4.append(N3[i] + x1[j])
                P4.append((P3[i] + y1[j]) * sample_step_y_p[3])
        N__4.extend(N4)
        P__4.extend(P4)
        for i in range(step ** 4):
            for j in range(step):
                N5.append(N4[i] + x1[j])
                P5.append((P4[i] + y1[j]) * sample_step_y_p[4])
        N__5.extend(N5)
        P__5.extend(P5)
        for i in range(step ** 5):
            for j in range(step):
                N6.append(N5[i] + x1[j])
                P6.append((P5[i] + y1[j]) * sample_step_y_p[5])
        N__6.extend(N6)
        P__6.extend(P6)
        for i in range(step ** 6):
            for j in range(step):
                N7.append(N6[i] + x1[j])
                P7.append((P6[i] + y1[j]) * sample_step_y_p[6])
        N__7.extend(N7)
        P__7.extend(P7)
        for i in range(step ** 7):
            for j in range(step):
                N8.append(N7[i] + x1[j])
                P8.append((P7[i] + y1[j]) * sample_step_y_p[7])
        N__8.extend(N8)
        P__8.extend(P8)
        for i in range(step ** 8):
            for j in range(step):
                N9.append(N8[i] + x1[j])
                P9.append((P8[i] + y1[j]) * sample_step_y_p[8])
        N__9.extend(N9)
        P__9.extend(P9)
        for i in range(step ** 9):
            for j in range(step):
                N10.append(N9[i] + x1[j])
                P10.append((P9[i] + y1[j]) * sample_step_y_p[9])
        N__10.extend(N10)
        P__10.extend(P10)
        for i in range(step ** 10):
            for j in range(step):
                N11.append(N10[i] + x1[j])
                P11.append((P10[i] + y1[j]) * sample_step_y_p[10])
        N__11.extend(N11)
        P__11.extend(P11)
        for i in range(step ** 11):
            for j in range(step):
                N12.append(N11[i] + x1[j])
                P12.append((P11[i] + y1[j]) * sample_step_y_p[11])
        N__12.extend(N12)
        P__12.extend(P12)
        for i in range(step ** 12):
            for j in range(step):
                N13.append(N12[i] + x1[j])
                P13.append((P12[i] + y1[j]) * sample_step_y_p[12])
        N__13.extend(N13)
        P__13.extend(P13)
        for i in range(step ** 13):
            for j in range(step):
                N14.append(N13[i] + x1[j])
                P14.append((P13[i] + y1[j]) * sample_step_y_p[13])
        N__14.extend(N14)
        P__14.extend(P14)
        for i in range(step ** 14):
            for j in range(step):
                N15.append(N14[i] + x1[j])
                P15.append((P14[i] + y1[j]) * sample_step_y_p[14])
        N__15.extend(N15)
        P__15.extend(P15)
        for i in range(step ** 15):
            for j in range(step):
                N16.append(N15[i] + x1[j])
                P16.append((P15[i] + y1[j]) * sample_step_y_p[15])
        N__16.extend(N16)
        P__16.extend(P16)
        for i in range(step ** 16):
            for j in range(step):
                N17.append(N16[i] + x1[j])
                P17.append((P16[i] + y1[j]) * sample_step_y_p[16])
        N__17.extend(N17)
        P__17.extend(P17)
        for i in range(step ** 17):
            for j in range(step):
                N18.append(N17[i] + x1[j])
                P18.append((P17[i] + y1[j]) * sample_step_y_p[17])
        N__18.extend(N18)
        P__18.extend(P18)
        for i in range(step ** 18):
            for j in range(step):
                N19.append(N18[i] + x1[j])
                P19.append((P18[i] + y1[j]) * sample_step_y_p[18])
        N__19.extend(N19)
        P__19.extend(P19)
        for i in range(step ** 19):
            for j in range(step):
                N20.append(N19[i] + x1[j])
                P20.append((P19[i] + y1[j]) * sample_step_y_p[19])
        N__20.extend(N20)
        P__20.extend(P20)

        N_2_proxy = np.concatenate((N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, N14, N15, N16, N17, N18, N19, N20), axis=0)
        P_2_proxy = np.concatenate((P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19, P20), axis=0)
        N_2 = np.append(N_2, N_2_proxy)
        P_2 = np.append(P_2, P_2_proxy)

    fig, ax = plt.subplots()
    ax.semilogx(N__1, P__1, '.')
    plt.plot(N__2, P__2, '.')
    plt.plot(N__3, P__3, '.')
    plt.plot(N__4, P__4, '.')
    plt.plot(N__5, P__5, '.')
    plt.plot(N__6, P__6, '.')
    plt.plot(N__7, P__7, '.')
    plt.plot(N__8, P__8, '.')
    plt.plot(N__9, P__9, '.')
    plt.plot(N__10, P__10, '.')
    plt.plot(N__11, P__11, '.')
    plt.plot(N__12, P__12, '.')
    plt.plot(N__13, P__13, '.')
    plt.plot(N__14, P__14, '.')
    plt.plot(N__15, P__15, '.')
    plt.plot(N__16, P__16, '.')
    plt.plot(N__17, P__17, '.')
    plt.plot(N__18, P__18, '.')
    plt.plot(N__19, P__19, '.')
    plt.plot(N__20, P__20, '.')
    name = []
    for i in range(degree_of_initiator):
        name.append(f'Protein with {i + 1} polymer chain(s)')
    plt.legend(name,prop={'size': 6},loc='upper right')
    plt.title('Conjugate GPC prediction')
    print("准备存储图片1")
    plt.savefig('img3.jpeg')
    order = np.argsort(N_2)
    N22 = []
    P22 = []
    for i in order:
        N22.append(N_2[i])
        P22.append(P_2[i])
    from itertools import groupby
    n2 = []
    # s=0
    # i,j=0,0
    p2 = []
    index = []
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        index.append(len(list(g)))
    for k, g in groupby(N22, key=lambda x: x // (Mw_mono * Smoothfactor)):
        n2.append(np.mean(list(g)))
    j = 0

    for i in index:
        s = np.sum(P22[j:j + i])
        j += i
        p2.append(s)

    fig, ax = plt.subplots()
    ax.semilogx(n2, p2, '.', color='darkgreen')
    plt.title('Conjugate  GPC Prediction (Combined)')
    print("准备存储图片2")
    plt.savefig('img4.jpeg')
    plt.close('all')
    x_conjugate = n2
    y_conjugate = p2

    def predict_verification3(Mw, baselined_intensity):
        ##Module calculation
        sigmaH = 0
        W = []
        M = []
        H = []
        sum_Wi_Mi = 0
        sum_WiMi = 0

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                sigmaH += y
                M.append(x)

        for x, y in zip(Mw, baselined_intensity):
            if x >= min2 and x <= max2:
                W.append(y / sigmaH)
                H.append(y)

        for i in range(len(W)):
            sum_Wi_Mi += W[i] / M[i]
            sum_WiMi += W[i] * M[i]

        Mn_tot = 1 / (sum_Wi_Mi)
        Mw_tot = sum_WiMi
        PDI = Mw_tot / Mn_tot
        Mn_tot= round(Mn_tot,2)
        Mw_tot = round(Mw_tot, 2)
        PDI = round(PDI,2)
        res = {
            'success': True,
            'Mn':Mn_tot,
            'Mw':Mw_tot,
            'PDI':PDI,
        }
        print(f'Mn is {Mn_tot:.1f} Da, Mw is {Mw_tot:.1f} Da, PDI is {PDI:.2f}')
        return res

    res = predict_verification3(x_conjugate, y_conjugate)

    return HttpResponse(json.dumps(res), content_type='application/json')

def getraw1(request):
    with open("protein.json") as json_file:
        raw = json.load(json_file)
    # print(raw)
    res = {
        'success': True,
        'initiator_mw': raw['initiator_mw'],
        'protein_mw':raw['protein_mw'],
        'degree_of_initiator': raw['degree_of_initiator'],
    }
    return HttpResponse(json.dumps(res), content_type='application/json')



def test(request):
    with open("polymer.json") as json_file:
        polymer = json.load(json_file)
    print(polymer)
    with open("protein6.json") as json_file:
        protein6 = json.load(json_file)
    res = {
        'success': True,
        'Mn': polymer['polymer_mn'],
        'PDI':polymer['polymer_pdi'],
        'Mw': polymer['monomer_mw'],
        'min':polymer['min'],
        'max':polymer['max'],
        'protein_mw':protein6['protein_mw'],
        'degree_of_initiator':protein6['degree_of_initiator']
    }
    return HttpResponse(json.dumps(res), content_type='application/json')


def getraw1(request):
    with open("protein.json") as json_file:
        raw = json.load(json_file)
    print(raw)
    res = {
        'success': True,
        'initiator_mw': raw['initiator_mw'],
        'protein_mw':raw['protein_mw'],
        'degree_of_initiator': raw['degree_of_initiator'],
    }
    return HttpResponse(json.dumps(res), content_type='application/json')


def write_protein5(request):
    data = json.loads(request.body)
    print(data)
    final_json = json.dumps(data, ensure_ascii=False)
    with codecs.open("protein5.json", 'w', 'utf-8') as file:
        file.write(final_json)

    protein6 = {
        'protein_mw':data["protein_mw"],
        'degree_of_initiator':data["degree_of_initiator"]
    }
    protein6_json = json.dumps(protein6, ensure_ascii=False)
    with codecs.open("protein6.json", 'w', 'utf-8') as file:
        file.write(protein6_json)
    print(data["degree_of_initiator"],data["protein_mw"])
    res = {
        'success': True
    }
    degree_of_initiator=data["degree_of_initiator"]
    fuck = [0]*degree_of_initiator
    sum = 0
    for i,item in enumerate(data["protein"]):
        # print(i,item)
        if item == None:
            break
        # print(item["number_of_initiators"], type(item["percentage"]))
        if item["number_of_initiators"] >=1 and item["number_of_initiators"] <= 20 and item["percentage"]>=0 and item["percentage"]<=1:
            sum += item["percentage"]
            # print((item["number_of_initiators"]-1),item["percentage"])
            a=(item["number_of_initiators"]-1)
            b=item["percentage"]
            print("ab",type(a),type(b))
            fuck[a] = b
    print(sum, fuck, len(fuck))
    if sum > 1 or sum <= 0:
        res = {
            'success': False
        }
    else:
        fuck = np.array(fuck)
        np.save("massratios.npy", fuck)
        test = np.load("massratios.npy")
        print("ll", test)
    return HttpResponse(json.dumps(res), content_type='application/json')

def write_conjugate(request):
    data = json.loads(request.body)
    # print(data)
    final_json = json.dumps(data, ensure_ascii=False)
    with codecs.open("conjugate.json", 'w', 'utf-8') as file:
        file.write(final_json)
    res = {
        'success': True
    }

    return HttpResponse(json.dumps(res), content_type='application/json')

def getraw3(request):
    with open("protein5.json") as json_file:
        raw = json.load(json_file)
    # print(raw)
    index = []
    num = []
    for i,item in enumerate(raw["protein"]):
        # print(i,item)


        if item == None:
            break
        a = item["number_of_initiators"]
        b = item["percentage"]
        index.append(a)
        num.append(b)
    # print(index,num)
    res = {
        'number':index,
        'percentage':num

    }
    return HttpResponse(json.dumps(res), content_type='application/json')