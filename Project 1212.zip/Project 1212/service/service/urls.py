"""service URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from server import views as server_views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('write/', server_views.write_polymer_server),
    path('writeprotein/', server_views.write_protein),
    # path('writeprotein2/', server_views.write_protein2),
    path('writeprotein5/', server_views.write_protein5),
    path('read/', server_views.read_server),
    path('img/',server_views.img),
    path('img2/',server_views.img2),
    path('img3/',server_views.img3),
    path('img4/',server_views.img4),
    # path('img5/',server_views.img5),
    path('csv/',server_views.handle_csv),
    path('conjugate1/',server_views.conjugate1),
    path('conjugate2/',server_views.conjugate2),
    path('conjugate3/', server_views.conjugate3),
    path('conjugate4/', server_views.conjugate4),
    path('conjugate5/', server_views.conjugate5),
    path('conjugate6/', server_views.conjugate6),
    path('conjugate7/', server_views.conjugate7),
    path('conjugate8/', server_views.conjugate8),
    path('conjugate9/', server_views.conjugate9),
    path('conjugate10/', server_views.conjugate10),
    path('conjugate11/', server_views.conjugate11),
    path('conjugate12/', server_views.conjugate12),
    path('conjugate13/', server_views.conjugate13),
    path('conjugate14/', server_views.conjugate14),
    path('conjugate15/', server_views.conjugate15),
    path('conjugate16/', server_views.conjugate16),
    path('conjugate17/', server_views.conjugate17),
    path('conjugate18/', server_views.conjugate18),
    path('conjugate19/', server_views.conjugate19),
    path('conjugate20/', server_views.conjugate20),
    path('test/',server_views.test),
    path('getraw1/',server_views.getraw1),
    # path('getraw2/',server_views.getraw2),
    path('getraw3/',server_views.getraw3),
    path('writeconjugate/', server_views.write_conjugate)

]
