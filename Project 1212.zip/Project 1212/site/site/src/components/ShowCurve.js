import React,{Component} from 'react';
import axios from 'axios';
const server= 'http://127.0.0.1:8000';

class ShowCurve extends Component {
    constructor (props) {
        super(props);
        this.state = {
          name: "",
          age: 0,
        }
        this.setState.bind(this);
    }
    render(){
        const url = this.props.url
        // console.log(key)
        return(
            <div>
                {/* <p>{key}</p> */}
                <img src={url}></img>
            </div>
        )
    }
}

export default ShowCurve;