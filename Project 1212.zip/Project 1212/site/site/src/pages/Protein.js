import DynamicAntdTheme from 'dynamic-antd-theme';
import React, {Component} from 'react';
import { render } from 'react-dom';
import 'antd/dist/antd.css';
import { Form, Input, Button, Checkbox, Layout, Divider, Space, Card, Col, Row, Typography,Tooltip } from 'antd';
import axios from 'axios';
import ShowCurve from '../components/ShowCurve'
import HandleCSV from './HandleCSV'
import { InfoCircleOutlined } from '@ant-design/icons';
const {Header} = Layout;
const { Title, Paragraph, Text, Link } = Typography;

axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/json';
const server= 'http://127.0.0.1:8000';
var key = 1;

class Protein extends Component {
    constructor(props) {
        super(props);
        this.state ={
            initiator_mw:0,
            protein_mw:0,
            degree_of_initiator:0,
            key:0,
            url:"",
            disable:true,
        };
        this.setState.bind(this);
        this.change = this.change.bind(this);
        this.write = this.write.bind(this);
    }
    
    change (key, e) {
        this.setState({
          [key]:e.target.value
        });
      }

    async write (values) {
        
        console.log(values);
        let res = await axios.post(`${server}/writeprotein/`, values);
        key++;
        this.setState({key:key, 
            disable:false,
        url:`http://127.0.0.1:8000/img?${key}`})
        console.log(res);
    }
    
    

    render() {
        const disable = this.state.disable
        const url = this.state.url
        const layout = {
          labelCol: { span: 10 },
          wrapperCol: { span: 10 },
         };
        const tailLayout = {
              wrapperCol: {
              offset: 4,
              span: 18,
             },
};
        
        
        const onFinishFailed = errorInfo => {
            console.log('Failed:', errorInfo);
          }; 
          
          

        return (
          <Layout className="layout" >
          <div className='theme-container'>

          <div style={{

                      backgroundImage: `url(${"https://www.cmu.edu/news/stories/archives/2018/march/images/nano-armor-900x600-min.jpg"})` ,
                      backgroundPosition: 'center',
                      // backgroundSize: 'cover',
                      // backgroundRepeat: 'no-repeat',
                      height:'1500px'
                      
                     }}>   
          <Header><h1 style={{color:'white', textAlign: 'center',width: '100%'}}>PROTEIN</h1></Header>
          <Row gutter={8}>
          <Col span={7}>
      
          </Col>
          <Col span={10}>
          <Card size="large">
                <Form 
      {...layout}
      name="basic"
      initialValues={{
        remember: true,
      }}
      onFinish={this.write}
      onFinishFailed={onFinishFailed}
    >
      <Form.Item
        label="Initiator Mw"
        name="initiator_mw"
        rules={[
          {
            required: true,
            message: 'Please input Initiator Mw!',
          },
        ]}
      >
        <Input suffix="Da" />
      </Form.Item><Form.Item {...tailLayout}><small>*Initiator Mw without leaving groups (e.g. NHS)</small></Form.Item>

      <Form.Item
        label="Native Protein Mw"
        name="protein_mw"
        rules={[
          {
            required: true,
            message: 'Please input Protein Mw!',
          },
        ]}
      ><Input suffix="Da" />
      </Form.Item>

      <Form.Item
        label="Degree of Initiator"
        name="degree_of_initiator"
        rules={[
          {
            required: true,
            message: 'Please input Degree of Initiator!',
          },
        ]}
      >
        <Input placeholder='integer 1-20'/>
      </Form.Item><Form.Item {...tailLayout}><small>*Maximum number of initiators captured by MALDI</small></Form.Item>
 
      <Form.Item {...tailLayout}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>  </Form.Item>
        <Form.Item {...tailLayout}> 
    <div ><small>Now upload your MALDI raw data</small>
        <HandleCSV disable={disable}/>
          </div> </Form.Item>
 
    </Form>     
         

    </Card>
    </Col>
    </Row></div></div>   
    <span>Change antd theme: </span>
      <DynamicAntdTheme />     
    </Layout>
        )
    }
}
export default Protein;