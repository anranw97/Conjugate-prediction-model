import React,{Component} from 'react';
import axios from 'axios';
import 'antd/dist/antd.css';
import { Upload, message, Button ,Layout, Form} from 'antd';
import { UploadOutlined } from '@ant-design/icons';
const server= 'http://127.0.0.1:8000';
const { Header, Content, Footer } = Layout;
var key =0;
class HandleCSV extends Component {
    constructor (props) {
        super(props);
        this.state = {
          name: "",
          age: 0,
          url:'',
          disable:true,
        //   disable:this.props.disable
        }
        this.setState.bind(this);
    
    }
    onChangeUrl = (info) =>{
        
        if (info.file.status !== 'uploading') {
            console.log('uploading',info.file, info.fileList);
          }
          if (info.file.status === 'done') {
            key++
            this.setState({url:`http://127.0.0.1:8000/img2?${key}`,disable:false})
            message.success(`${info.file.name} file uploaded successfully`);
          } else if (info.file.status === 'error') {
            message.error(`${info.file.name} file upload failed.`);
          }
    }
    render(){
        const layout = {
        labelCol: { span: 10 },

        wrapperCol: { span: 8 },
       };
        const tailLayout = {
            wrapperCol: {
            offset: 0,
            span: 18,
           },
};
        const disable = this.props.disable
        const url = this.state.url;
        const props = {
            name: 'file',
            method:'post',
            action: `${server}/csv/`,
            accept:'text/csv',
            headers: {
              authorization: { 'content-type': 'text/xml' },
            },
            onChange: this.onChangeUrl
          };
        return(
            <div>
                <br />
                <Upload {...props} showUploadList={true} disabled={disable}>
                    <Button>
                    <UploadOutlined />Click to Upload: MALDI raw data (.csv)
                    </Button>
                </Upload>,
                <Form><Form.Item {...tailLayout}>
                <img src = {url} width={350}></img>
                
    <Button type="primary" href="http://localhost:3000/conjugate/1" disabled={this.state.disable}>Next Step</Button>
    </Form.Item></Form>
            </div>
        )
    }
}

export default HandleCSV;