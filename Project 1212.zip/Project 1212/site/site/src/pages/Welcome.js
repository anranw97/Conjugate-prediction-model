import DynamicAntdTheme from 'dynamic-antd-theme';
import React, {Component} from 'react';
import { render } from 'react-dom';
import 'antd/dist/antd.css';
import { Form, Input, Button, Checkbox, Layout, Divider, Space, Card, Col, Row, Typography, Buttom } from 'antd';
import axios from 'axios';
import ShowCurve from '../components/ShowCurve'


const { Header, Content, Footer } = Layout;
const { Title, Paragraph, Text, Link } = Typography;
class Welcome extends Component {
    constructor (props) {
        super(props);
        this.state = {
      
        }
        this.setState.bind(this)
    
      }
render() {

    const layout = {
                    labelCol: { span: 10 },

                    wrapperCol: { span: 8 },
                   };
    const tailLayout = {
                        wrapperCol: {
                        offset: 4,
                        span: 18,
                       },
          };
    
    

    return (
      <div>
        <Layout className="layout" >
        <div className='theme-container'>
        

        <div style={{

                    backgroundImage: `url(${"https://www.cmu.edu/news/stories/archives/2018/march/images/nano-armor-900x600-min.jpg"})` ,
                    backgroundPosition: 'center',
                    // backgroundSize: 'cover',
                    // backgroundRepeat: 'no-repeat',
                    height:'900px'
                    
                   }}>   
        <Header><h1 style={{color:'white', textAlign: 'center',width: '100%'}}>Welcome to ConjugateCalculator Online!</h1></Header>
        <Row gutter={0}>
        <Col span={7}>
    
        </Col>
       <Col span={10}>
       <Card size="large">

    <Typography{...layout}>
    <Title level={3}>
    Our website helps you generate predicted conjugate MWD curves, molecular weights and dispersity(PDI) values.
    </Title>
    All you need are as follows:
    <Paragraph>
      <Text strong><li>
      1.Polymer molecular weight and dispersity(PDI)</li><li>
      2.Initiated protein MALDI data </li></Text></Paragraph>
      <Button type="primary" href="http://localhost:3000/polymer"><div orientation='center' style={{color:"white"}}>Start</div></Button> 
      <br/> <br/>
      <Space direction="vertical">
 <small><li>Guidelines and Resources</li><li>
      *Our calculation model is based on stepwise chemistry of linear polymer chain attachment to initiated protein.
</li><li>
      *Our website serves as complement to current characterization techniques.
      </li><li>
      *You can find model and network files<Link href="http://www.github.com"> here.</Link></li>
      <li> *Email your advice or questions to eileena.wang20@gmail.com </li>
</small></Space>


  </Typography>
</Card>
</Col>
</Row></div> </div>
<span>Change antd theme: </span>
        <DynamicAntdTheme />  
</Layout>
      </div>
        
    )

}}

export default Welcome;

