import DynamicAntdTheme from 'dynamic-antd-theme';
import React, {Component} from 'react';
import { render } from 'react-dom';
import 'antd/dist/antd.css';
import { Form, Input, Button, Checkbox, Layout, Divider, Space, Card, Col, Row, Typography, tooltip } from 'antd';
import axios from 'axios';
import ShowCurve from '../components/ShowCurve'


const { Title, Paragraph, Text, Link } = Typography;
const { Header, Content, Footer } = Layout;
axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/json';
const server= 'http://127.0.0.1:8000';
var key = 1;

class Polymer extends Component {
    constructor(props) {
        super(props);
        this.state ={
            polymer_mn:0,
            polymer_pdi:0,
            monomer_mw:0,
            key:0,
            url:"",
            disable:true,
        };
        this.setState.bind(this);
        this.change = this.change.bind(this);
        this.write = this.write.bind(this);
        this.write_minmax = this.write_minmax.bind(this);
    }
    
    change (key, e) {
        this.setState({
          [key]:e.target.value
        });
      }

    async write (values) {
        
        console.log(values);
        let res = await axios.post(`${server}/write/`, values);
        key++;
        this.setState({key:key, 
        url:`http://127.0.0.1:8000/img?${key}`,
        polymer_mn:values["polymer_mn"],
        monomer_mw:values["monomer_mw"],
        polymer_pdi:values["polymer_pdi"],
        disable:false})
        console.log(res);
    }

    async write_minmax (values) {
        
      
      values["polymer_mn"] = this.state.polymer_mn;
      values["monomer_mw"] = this.state.monomer_mw;
      values["polymer_pdi"] = this.state.polymer_pdi;
      console.log(values);
      let res = await axios.post(`${server}/write/`, values);
      key++;
      this.setState({key:key, 
      url:`http://127.0.0.1:8000/img?${key}`,
      disable:false})
      console.log(res);
  }
   
    render() {
        const url = this.state.url
        const layout = {
                        labelCol: { span: 10 },

                        wrapperCol: { span: 8 },
                       };
        const tailLayout = {
                            wrapperCol: {
                            offset: 4,
                            span: 18,
                           },
              };
        
        
        const onFinishFailed = errorInfo => {
            console.log('Failed:', errorInfo);
          };  
        return (
        
            <Layout className="layout" >
            <div className='theme-container'>
      
            <div style={{

                        backgroundImage: `url(${"https://www.cmu.edu/news/stories/archives/2018/march/images/nano-armor-900x600-min.jpg"})` ,
                        backgroundPosition: 'center',
                        // backgroundSize: 'cover',
                        // backgroundRepeat: 'no-repeat',
                        height:'1500px'
                        
                       }}>   
            <Header><h1 style={{color:'white', textAlign: 'center',width: '100%'}}>POLYMER</h1></Header>
            <Row gutter={8}>
            <Col span={7}>
        
            </Col>
           <Col span={10}>
           <Card size="large">
              <div>
      <Form
      {...layout}
      name="basic"
      initialValues={{
        remember: true,
      }}
      onFinish={this.write}
      onFinishFailed={onFinishFailed}
    >
      
      <Form.Item
        label="Polymer Mn"
        name="polymer_mn"
        rules={[
          {
            required: true,
            message: 'Please input Polymer Mn!',
          },
        ]}
      >
      <Input suffix="Da" />
      </Form.Item>

      <Form.Item
        label="Polymer PDI"
        name="polymer_pdi"
        rules={[
          {
            required: true,
            message: 'Please input Polymer PDI!',
          },
        ]}
      >
      <Input placeholder="larger than 1"/>
      </Form.Item>

      <Form.Item
        label="Monomer Mw"
        name="monomer_mw"
        
        rules={[
          {
            required: true,
            message: 'Please input Monomer Mw!',
          },
        ]}
      >
        <Input suffix="Da" />
      </Form.Item>
      <Form.Item {...tailLayout}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
  
    <img src={url} key={key} width={350}></img >    </Form.Item>
    </Form>

<small>*Our default MW range is 100-500,000</small>
<br></br>
<small>*In order to maintain calculation efficiency, please customize your peak range</small>
<br></br>
<br></br>
<Form
      {...layout}
      name="basic"
      initialValues={{
        remember: true,
      }}
      onFinish={this.write_minmax}
      onFinishFailed={onFinishFailed}
    >
      
      <Form.Item 
        label="Min"
        name="min"
        rules={[
          {
            required: true,
            message: 'Please input Min!',
          },
        ]}
      >
      <Input/>
      </Form.Item>

      <Form.Item
        label="Max"
        name="max"
        rules={[
          {
            required: true,
            message: 'Please input Max!',
          },
        ]}
      >
      <Input />
      </Form.Item>

      <Form.Item {...tailLayout}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
      </Form>

<small><Text strong>Next, we provide two input options for intiated protein</Text></small>
<br></br>
<small>*If you have a MALDI image, extract raw data using Graph Grabber as csv file and take <Text strong>Option 1</Text></small>
<br></br>
<small>*If you have a csv file (first column:MW, second column:signal), take <Text strong>Option 1</Text></small>
<br></br>
<small>*If you have mass ratios of different initiator numbers, take <Text strong>Option 2</Text></small>
<br/><br/>   
    <div ><Form><Form.Item {...tailLayout}>
    {/* <Header><h1 style={{color:'white', textAlign: 'center',width: '100%'}}>Protein Input Options</h1></Header> */}
    <Button  type="primary" href="http://localhost:3000/protein" disabled={this.state.disable}>Option 1: MALDI Raw Data</Button>
    <br/><br/>
    <Button type="primary" href="http://localhost:3000/protein3" disabled={this.state.disable}>Option 2: Numerical{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}</Button>
    <br/><br/></Form.Item></Form></div>           
    </div>  
    </Card>
    </Col>
    </Row></div> </div>      
    <span>Change antd theme: </span>
      <DynamicAntdTheme /> 
    </Layout>
        )
    }
}

export default Polymer;