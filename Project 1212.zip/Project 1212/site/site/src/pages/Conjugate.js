import DynamicAntdTheme from 'dynamic-antd-theme';
import React,{Component} from 'react';
import axios from 'axios';
import 'antd/dist/antd.css';
import { Modal, Button ,Card, Layout, Table, Form, Input, Tooltip, Row, Col} from 'antd';
import { ExclamationCircleOutlined } from '@ant-design/icons';
const { Header, Content, Footer } = Layout;
axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/json';
const server= 'http://127.0.0.1:8000';
var key = 1;

class Conjugate extends Component {
  constructor (props) {
    super(props);
    this.state = {
      Mn:undefined,
      Mw:undefined,
      PDI:undefined,
      url1:"",
      url2:"",
      id:props.match.params.id,
      showList: [],
    }
    this.setState.bind(this)
    this.change = this.change.bind(this);
    this.write = this.write.bind(this);
    this.read = this.read.bind(this);
  }
  async componentWillMount() {
    var show = []
    console.log("开始获取showlist")
    let polymer = await axios.get(`${server}/test/`)
    if(this.state.id == 1){
      let raw = await axios.get(`${server}/getraw1/`)
      let raw2 = await axios.get(`${server}/getraw3/`)
      let table = []
      for(let i = 0;i<raw2.data.number.length;i++){
        // console.log(raw.data.number[i])
        

          let cont = {key:i, 
            number:raw2.data.number[i].toString(),
            percentage:(raw2.data.percentage[i]*100).toFixed(2).toString().concat("%")
          }
          // console.log(cont)
          table.push(cont)
    
      }
      show = ({
        polymer_mn: polymer.data.Mn,
        polymer_pdi:polymer.data.PDI,
        monomer_mw: polymer.data.Mw,
        min:polymer.data.min,
        max:polymer.data.max,
        initiator_mw: raw.data?raw.data.initiator_mw:raw.data,
        protein_mw: raw.data?raw.data.protein_mw:raw.data,
        degree_of_initiator: raw.data?raw.data.degree_of_initiator:raw.data,
        table:table
      })
    
    }


    else{
      let raw = await axios.get(`${server}/getraw3/`)
      console.log(raw)
     
      let table = []
      for(let i = 0;i<raw.data.number.length;i++){
        // console.log(raw.data.number[i])
        

          let cont = {key:i, 
            number:raw.data.number[i].toString(),
            percentage:(raw.data.percentage[i]*100).toFixed(2).toString().concat("%")
          }
          // console.log(cont)
          table.push(cont)
    
      }
          
      console.log(table)
      show = ({
        polymer_mn: polymer.data.Mn,
        polymer_pdi:polymer.data.PDI,
        monomer_mw: polymer.data.Mw,
        min:polymer.data.min,
        max:polymer.data.max,
        protein_mw:polymer.data.protein_mw,
        degree_of_initiator:polymer.data.degree_of_initiator,
        table:table
      })
    }
    this.setState({
      showList:show,
    })
    
  }

  change (key, e) {
    this.setState({
      [key]:e.target.value
    });
  }

  async write () {
    let data = {...this.state};
    console.log(data);
    
    let res = await axios.post(`${server}/write/`, data);
    console.log(res);
  }
  async write3 (values) {
        
    console.log(values);
    let res = await axios.post(`${server}/writeconjugate/`, values);
    console.log(res);
}
  async read () {
    Modal.confirm({
        title:'It takes minutes to run conjugate prediction calculation. Are you sure to continue?',
        content:'',
        okText:'Yes, continue.',
        okType: 'danger',
        cancelText:'No',
        onOk: async () => {
            
            let res = await axios.get(`${server}/conjugate${this.state.showList.degree_of_initiator}/`);
            this.setState({Mn:res.data.Mn,
                Mw:res.data.Mw,
                PDI:res.data.PDI,
                url1:`http://127.0.0.1:8000/img3?${key}`,
                url2:`http://127.0.0.1:8000/img4?${key}`,
            })
            key++;
            
        }
        ,
        onCancel() {
            console.log('no')         
        },
    })
    
  }

  render() {
    
    const id = this.state.id
    console.log(id)
    console.log(this.state.showList)
    const layout = {
      labelCol: { span: 12 },

      wrapperCol: { span: 8 },
     };
    const tailLayout = {
          wrapperCol: {
          offset: 2,
          span: 18,
         },}
         const tailLayout2 = {
          wrapperCol: {
          offset: 4,
          span: 18,
         },}   
   
    var card;
    var table;
    const columns = [
      {
        title: 'Number of initiators',
        dataIndex: 'number',
        align: 'center',
      },
      {
        title: 'Weight percentage',
        dataIndex: 'percentage',
        align: 'center',
      },  
    ];
    
  
    if(id == 1){
      table = <Table columns={columns} dataSource={this.state.showList.table} size="small" />
      card = <Card title="Inputs Overview" bordered={false}>
      <p>Polymer Mn: {this.state.showList.polymer_mn} Da</p>
      <p>Polymer PDI: {this.state.showList.polymer_pdi} </p>
      <p>Monomer Mw: {this.state.showList.monomer_mw} Da</p>
      <p>MW min: {this.state.showList.min} Da</p>
      <p>MW max: {this.state.showList.max} Da</p>
      <p>Initiator Mw: {this.state.showList.initiator_mw} Da</p>     
      <p>Protein Mw: {this.state.showList.protein_mw} Da</p>
      <p>Degree of initiator: {this.state.showList.degree_of_initiator}</p>
      <p>MALDI raw data: your csv file</p>
      </Card>
    }

    else {
      table = <Table columns={columns} dataSource={this.state.showList.table} size="small" />
      card = <Card title="Inputs Overview" bordered={false} >
      <p>Polymer Mn: {this.state.showList.polymer_mn} Da</p>
      <p>Polymer PDI: {this.state.showList.polymer_pdi}</p>
      <p>Monomer Mw: {this.state.showList.monomer_mw} Da</p>
      <p>MW min: {this.state.showList.min} Da</p>
      <p>MW max: {this.state.showList.max} Da</p>
      <p>Protein Mw: {this.state.showList.protein_mw} Da</p>
      <p>Degree of initiator: {this.state.showList.degree_of_initiator}</p>
      </Card>
    }
    const onFinishFailed = errorInfo => {
      console.log('Failed:', errorInfo);
    }; 
    return (
      <Layout className="layout" >
      <div className='theme-container'>


      <div style={{

                  backgroundImage: `url(${"https://www.cmu.edu/news/stories/archives/2018/march/images/nano-armor-900x600-min.jpg"})` ,
                  backgroundPosition: 'center',
                  // backgroundSize: 'cover',
                  // backgroundRepeat: 'no-repeat',
                  height:'1500px'
                  
                 }}>   
      <Header><h1 style={{color:'white', textAlign: 'center',width: '100%'}}>CONJUGATE</h1></Header>      
           <Row gutter={0}>
            <Col span={6}>
        
            </Col>
           <Col span={12}>
           <Card size="large"><div>
        

      <Form
      {...layout}
      name="basic"
      initialValues={{
        remember: true,
      }}
      onFinish={this.write3}
      onFinishFailed={onFinishFailed}
    >
      
      
      <Form.Item
        label="Number of feeding data points"
        name="Number_polymer"
        rules={[
          {
            required: true,
            message: 'Please input Number of feeding data points!',
          },
        ]}
      >
      <Input/>
      </Form.Item>

      <Form.Item
        label="Size of minimum calculation unit"
        name="step"
        rules={[
          {
            required: true,
            message: 'Please input Size of minimum calculation unit!',
          },
        ]}
      >
      <Input />
      </Form.Item>

      <Form.Item
        label="Smoothfactor"
        name="Smoothfactor"
        
        rules={[
          {
            required: true,
            message: 'Please input Smoothfactor!',
          },
        ]}
      >
        <Input />
      </Form.Item>
      <Form.Item {...tailLayout}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button><span> </span>
        <Button type="primary" onClick={this.read}>
          Calculate
        </Button>
        </Form.Item>
        </Form> </div></Card></Col></Row>
        
        <Form.Item {...tailLayout2}>
          
        <Row gutter={30}>
        <Col span={10}> <br></br> 
                {card}<br></br> 
                {table}</Col>
        <Col span={11}><br></br>
        <Card title="Conjugate Prediction Results" bordered={false} >
        <p>Conjugate Mn: {this.state.Mn} Da</p>
        <p>Conjugate Mw: {this.state.Mw} Da</p>
        <p>Conjugate PDI: {this.state.PDI}</p>        
        <img src={this.state.url1} width={350}></img>
        <img src={this.state.url2} width={350}></img>
        </Card></Col>
        
        </Row>

      
        <Button type="primary" href="http://localhost:3000/" >Back To Beginning</Button>
        
        </Form.Item>
        <br></br>
      </div></div>
      <span>Change antd theme: </span>
      <DynamicAntdTheme />
      </Layout>
    );
  }
}

export default Conjugate;
 