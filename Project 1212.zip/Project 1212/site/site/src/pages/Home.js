import React, {Component} from 'react';
import { render } from 'react-dom';
import 'antd/dist/antd.css';
import { Form, Input, Button, Checkbox, Layout, Divider } from 'antd';
import axios from 'axios';
import ShowCurve from '../components/ShowCurve'
const { Header, Content, Footer } = Layout;
axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/json';
const server= 'http://127.0.0.1:8000';
var key = 1;

class Home extends Component {
    constructor(props) {
        super(props);
        this.state ={
            polymer_mw:0,
            polymer_pdi:0,
            monomer_mw:0,
            key:0,
            url:"",
            disable:true,
        };
        this.setState.bind(this);
        this.change = this.change.bind(this);
        this.write = this.write.bind(this);
    }
    
    change (key, e) {
        this.setState({
          [key]:e.target.value
        });
      }

    async write (values) {
        
        console.log(values);
        let res = await axios.post(`${server}/write/`, values);
        key++;
        this.setState({key:key, 
        url:`http://127.0.0.1:8000/img?${key}`,
        disable:false})
        console.log(res);
    }
    

    render() {
        const url = this.state.url
        const layout = {
            labelCol: {
              span: 4,
            },
            wrapperCol: {
              span: 4,
            },
        };
        const tailLayout = {
            wrapperCol: {
              offset: 4,
              span: 4,
            },
        };
        
        
        const onFinishFailed = errorInfo => {
            console.log('Failed:', errorInfo);
          };  
        return (
            <Layout className="layout">
            <Header><h1 style={{color:"white"}}>POLYMER</h1></Header>
            <div>
                <br/>
                <Form
      {...layout}
      name="basic"
      initialValues={{
        remember: true,
      }}
      onFinish={this.write}
      onFinishFailed={onFinishFailed}
    >
        
      <Form.Item
        label="Polymer Mn"
        name="polymer_mw"
        rules={[
          {
            required: true,
            message: 'Please input Polymer Mw!',
          },
        ]}
      >
        <Input />
      </Form.Item>
      <Form.Item
        label="Polymer PDI"
        name="polymer_pdi"
        rules={[
          {
            required: true,
            message: 'Please input Polymer PDI!',
          },
        ]}
      >
        <Input />
      </Form.Item>
      <Form.Item
        label="Monomer Mw"
        name="monomer_mw"
        rules={[
          {
            required: true,
            message: 'Please input Monomer Mw!',
          },
        ]}
      >
        <Input />
      </Form.Item>

      

      <Form.Item {...tailLayout}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
    <img src={url} key={key}></img>
    <Divider orientation="center" plain>Protein Input Options</Divider>
    <div style={{padding:"0px 0px 0px 300px"}}>
      <Button type="primary" href="http://localhost:3000/protein" disabled={this.state.disable}>Option1: MALDI raw data</Button>
    <br/><br/>
      <Button type="primary" href="http://localhost:3000/protein2" disabled={this.state.disable}>Option 2: numerical{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}</Button>
      <br/><br/>
      <Button type="primary" href="http://localhost:3000/protein3" disabled={this.state.disable}>Option 3: numerical{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}{" ".replace(/ /g, "\u00a0")}</Button>
    <br/>
    </div>
    <br/>
            </div>
        </Layout>
        )
    }
}
export default Home;