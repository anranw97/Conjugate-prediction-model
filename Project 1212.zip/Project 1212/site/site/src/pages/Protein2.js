import React, {Component} from 'react';
import { render } from 'react-dom';
import 'antd/dist/antd.css';
import { Form, Input, Button, Checkbox, Divider ,Layout} from 'antd';
import axios from 'axios';
import ShowCurve from '../components/ShowCurve'
import HandleCSV from './HandleCSV'
const {Header} = Layout
axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/json';
const server= 'http://127.0.0.1:8000';
var key = 1;

class Protein2 extends Component {
    constructor(props) {
        super(props);
        this.state ={
            initiator_mw:0,
            protein_mw:0,
            degree_of_initiator:0,
            key:0,
            url:"",
            disable:true,
        };
        this.setState.bind(this);
        this.change = this.change.bind(this);
        this.write = this.write.bind(this);
    }
    
    change (key, e) {
        this.setState({
          [key]:e.target.value
        });
      }

    async write (values) {
        
        console.log(values);
        let res = await axios.post(`${server}/writeprotein2/`, values);
        key++;
        this.setState({key:key, 
            disable:false,
        url:`http://127.0.0.1:8000/img5?${key}`})
        console.log(res);
    }
    
    

    render() {
        const disable = this.state.disable
        const url = this.state.url
        const layout = {
            labelCol: {
              span: 4,
            },
            wrapperCol: {
              span: 4,
            },
        };
        const tailLayout = {
            wrapperCol: {
              offset: 4,
              span: 4,
            },
        };
        
        
        const onFinishFailed = errorInfo => {
            console.log('Failed:', errorInfo);
          }; 
          
          

        return (
            <Layout className="layout" >
            <Header><h1 style={{color:"white"}}>PROTEIN</h1></Header>
            <div >
                <br/>
                {/* <Divider orientation="center" plain>first step</Divider> */}
                <Form 
      {...layout}
      name="basic"
      initialValues={{
        remember: true,
      }}
      onFinish={this.write}
      onFinishFailed={onFinishFailed}
    >
      <Form.Item
        label="Initiator Mw (Da)"
        name="initiator_mw"
        rules={[
          {
            required: true,
            message: 'Please input Initiator Mw!',
          },
        ]}
      >
        <Input />
      </Form.Item>
      <Form.Item
        label="Protein Mw (Da)"
        name="protein_mw"
        rules={[
          {
            required: true,
            message: 'Please input Protein Mw!',
          },
        ]}
      >
        <Input />
      </Form.Item>
      <Form.Item
        label="Degree of Initiator"
        name="degree_of_initiator"
        rules={[
          {
            required: true,
            message: 'Please input Degree of Initiator!',
          },
        ]}
      >
        <Input />
      </Form.Item>
      
      <Form.Item
        label="Average degree of modification"
        name="average_degree_of_modification"
        rules={[
          {
            required: true,
            message: 'Please input Average degree of modification!',
          },
        ]}
      >
        <Input />
      </Form.Item>
    <Form.Item
            label="Distribution of degree of modification index (DDMI)"
            name="DDMI"
            rules={[
            {
                required: true,
                message: 'Please input Distribution of degree of modification index (DDMI)!',
            },
            ]}
        >
            <Input />
        </Form.Item>
      

      <Form.Item {...tailLayout}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
    {/* <img src={url} key={key}></img> */}
    {/* <Divider orientation="center" plain>second step</Divider>
    <div style={{padding:"0px 0px 0px 300px"}}>
        <HandleCSV disable={disable}/>
    </div> */}
    <img src={url} key={key}></img>
    <div style={{padding:"0px 0px 0px 500px"}}>
    <Button type="primary" href="http://localhost:3000/conjugate/2" disabled={this.state.disable}>Next Step</Button>
    </div>

    <br/>
            </div>
            </Layout>
        )
    }
}
export default Protein2;