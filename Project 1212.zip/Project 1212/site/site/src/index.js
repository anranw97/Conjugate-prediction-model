import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {localeReducer as locale, initialize, addTranslation} from 'react-localize-redux';
import {createStore, combineReducers} from 'redux';
import {Provider} from 'react-redux';
import * as serviceWorker from './serviceWorker';
import {BrowserRouter, Route} from 'react-router-dom';
import Home from './pages/Home'
import HandleCSV from './pages/HandleCSV'
import Protein from './pages/Protein'
import Protein2 from './pages/Protein2'
import Conjugate from './pages/Conjugate'
import Welcome from './pages/Welcome'
import Polymer from './pages/Polymer'
const store = createStore(combineReducers({locale}));
ReactDOM.render(
  <Provider store={store}>
    <BrowserRouter>
      <div>
        <Route exact path='/protein3' component={App}/>
        <Route exact path='/polymer' component={Polymer}/>
        <Route path='/test' component={Home}/>
        <Route  path='/csv' component={HandleCSV}/>
        <Route  path='/protein' component={Protein}/>
        <Route  path='/protein2' component={Protein2}/>
        <Route  path='/conjugate/:id' component={Conjugate}/>
        <Route exact path='/' component={Welcome}/>
      </div>
      </BrowserRouter>
  </Provider>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
