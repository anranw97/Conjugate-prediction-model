import DynamicAntdTheme from 'dynamic-antd-theme';
import React, { Component } from "react";
import ReactDOM, { render } from "react-dom";
import "antd/dist/antd.css";
import "./index.css";
import { Form, Input, Button, Col, Row, InputNumber ,Layout, Card} from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";
import axios from 'axios';
const {Header} = Layout

const server= 'http://127.0.0.1:8000';
const rules = [{ required: true ,
  type: 'number'}];
const layout = {
    labelCol: {
      span: 4,
    },
    wrapperCol: {
      span: 4,
    },
};
const tailLayout = {
    wrapperCol: {
      offset: 4,
      span: 4,
    },
};
var disable = true;

class App extends Component {
  constructor(props) {
    super(props);
    this.state ={
        initiator_mw:0,
        protein_mw:0,
        degree_of_initiator:0,
        key:0,
        url:"",
        disable:true,
    };}
    
    render() {
      const onFinish = async values => {
        console.log(values)
        console.log(values.protein instanceof Array);
        
        if(values.protein instanceof Array){
          let inputs = []
          let max = 0
          values.protein.map(value => {
            max = value.number_of_initiators > max ? value.number_of_initiators: max;
            inputs.push({number_of_initiators:value.number_of_initiators, percentage:value.percentage/100})
          })
          console.log("获取的输入", inputs, "最大序号", max)
          let res = await axios.post(`${server}/writeprotein5/`, {protein:inputs,protein_mw:values.protein_mw,degree_of_initiator:max});
          
        console.log(res);
        if(res.data.success)
        this.setState({disable:false})
        }
        
      };
      
      return (
        <Layout className="layout" >
            <div className='theme-container'>

            <div style={{

                        backgroundImage: `url(${"https://www.cmu.edu/news/stories/archives/2018/march/images/nano-armor-900x600-min.jpg"})` ,
                        backgroundPosition: 'center',
                        // backgroundSize: 'cover',
                        // backgroundRepeat: 'no-repeat',
                        height:'1500px'
                        
                       }}>   
            <Header><h1 style={{color:'white', textAlign: 'center',width: '100%'}}>PROTEIN</h1></Header>
            <Row gutter={8}>
            <Col span={6}>
        
            </Col>
           <Col span={12}>
           <Card size="large">
              <div></div>

                <Form onFinish={onFinish} className="my-form">
                  <Form.Item
                  label=" Native Protein Mw"
                  name="protein_mw"
                  rules={[
                    {
                      required: true,
                      message: 'Please input Protein Mw!',
                    },
                  ]}
                  ><Input suffix="Da" />
                  </Form.Item>
     
          <Form.List name="protein">
            {(fields, { add, remove }) => {
              /**
               * `fields` internal fill with `name`, `key`, `fieldKey` props.
               * You can extends this into sub field to support multiple dynamic fields.
               */
              return (
                <div>
                  {fields.map((field, index) => index<20?(
                    <Row key={field.key}>
                      <Col>
                        <Form.Item
                          label='Number of initiators'
              
                          name={[field.name, "number_of_initiators"]}
                          fieldKey={[field.fieldKey, "number_of_initiators"]}
                          rules={rules}
                        >
                          <InputNumber style={{ width: '80px' }} />
                        </Form.Item>
                      </Col>
                      <span> &nbsp; &nbsp;&nbsp;</span>
                      <Col>
                        <Form.Item
                          label='Mass Percentage'
                          name={[field.name, "percentage"]}
                          fieldKey={[field.fieldKey, "percentage"]}
                          rules={rules}
                        >
                          <InputNumber style={{ width: '80px' }} defaultValue={100}
                        min={0}
                        max={100}
                        formatter={value => `${value}%`}
                        parser={value => value.replace('%', '')} placeholder="Weight percentage" />
                        </Form.Item>
                      </Col>     
                      <span> &nbsp; &nbsp;&nbsp;</span>
                      <Col flex="none">
                        <MinusCircleOutlined
                          className="dynamic-delete-button"
                          onClick={() => {
                            remove(field.name);
                          }}
                        />
                      </Col>
                    </Row>
                  ):(<div></div>))}
                  <Form.Item>
                    <Button
                      type="dashed"
                      onClick={() => {
                        add();
                      }}
                      style={{ width: "100%" }}
                    >
                      <PlusOutlined /> Add field (max is 20)
                    </Button>
                  </Form.Item>
                </div>
              );
            }}
          </Form.List>
    
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
       
        <div>
        <Button type="primary" href="http://localhost:3000/conjugate/3" disabled={this.state.disable}>Next Step</Button>
        </div>
         </Form>
        </Card>
        </Col></Row>
        </div></div>
        <span>Change antd theme: </span>
            <DynamicAntdTheme />
        </Layout>
        
      );
    }
}



export default App;